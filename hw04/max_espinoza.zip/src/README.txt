HOMEWORK 4: STENCIL BUFFER & GLSL SHADERS

NAME:  < Max Espinoza >


TOTAL TIME SPENT:  < 20-30 >
Please estimate the number of hours you spent on this assignment.


COLLABORATORS: 
You must do this assignment on your own, as described in the 
Academic Integrity Policy.  If you did discuss the problem or errors
messages, etc. with anyone, please list their names here.

People in the lab, Rebecca


MIRROR RENDERING:
< insert comments on the implementation, known bugs, discussion of
lighting artifacts & fixes for extra credit >

Mirror works!



SHADOW VOLUMES:
< insert comments on the implementation, known bugs, extra credit >

Shadow Volumes visualization renders, however there are mutiple of each extended shadow edges points.
There cause miscounts in the actually calculation in shadow volumes.

GLSL SHADERS: 
< insert comments on the implementation, command line to run your new
shader(s), sample output, known bugs, extra credit >

I cound't get wood to work. But I did implement a watermelon with noise glare. 
I was hungry.


OTHER NEW FEATURES OR EXTENSIONS FOR EXTRA CREDIT:
< include instructions for use and test cases and sample output as
appropriate >
